// Une erreur « prévue » : elle porte le statut HTTP et un code stable pour les clients
export class AppError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
  ) {
    super(message);
  }
}
