import { appendFile, mkdir } from "node:fs/promises";
import { dirname } from "node:path";
import type { Notification, Notifier } from "./notifier.js";

// Pour les démonstrations et les tests : une ligne JSON par message dans une « boîte d'envoi »
export class FileNotifier implements Notifier {
  constructor(private readonly file: string) {}

  async send(notification: Notification): Promise<void> {
    await mkdir(dirname(this.file), { recursive: true });
    await appendFile(this.file, JSON.stringify({ ...notification, sentAt: new Date().toISOString() }) + "\n");
  }
}
