export type Notification = { to: string; subject: string; body: string };

// Ce dont le métier a besoin : « envoyer un message ». Peu importe comment.
export interface Notifier {
  send(notification: Notification): Promise<void>;
}
