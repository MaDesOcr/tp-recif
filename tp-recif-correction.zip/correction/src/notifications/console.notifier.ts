import type { Notification, Notifier } from "./notifier.js";

// En développement : le message s'affiche dans le terminal
export class ConsoleNotifier implements Notifier {
  async send({ to, subject, body }: Notification): Promise<void> {
    console.log(`[notification] à ${to} — ${subject}\n${body}`);
  }
}
