import { AppError } from "../errors/app-error.js";

// Une petite boîte à outils de validation, écrite une fois et partagée par toutes les routes.
// Une règle reçoit une valeur et renvoie un message d'erreur, ou null si la valeur est valide.
export type Rule = (value: unknown) => string | null;
export type Schema = Record<string, Rule>;

export const text =
  (min: number, max: number): Rule =>
  (value) =>
    typeof value === "string" && value.trim().length >= min && value.trim().length <= max
      ? null
      : `texte de ${min} à ${max} caractères attendu`;

export const oneOf =
  (values: readonly string[]): Rule =>
  (value) =>
    typeof value === "string" && values.includes(value) ? null : `valeur attendue parmi : ${values.join(", ")}`;

export const email: Rule = (value) =>
  typeof value === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ? null : "adresse email invalide";

// AAAA-MM-JJ, et une date qui existe (pas de 30 février)
export const isoDate: Rule = (value) => {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return "date au format AAAA-MM-JJ attendue";
  const date = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().startsWith(value) ? null : "cette date n'existe pas";
};

// Champ facultatif : absent ou null, il est accepté ; présent, il doit respecter la règle
export const optional =
  (rule: Rule): Rule =>
  (value) =>
    value === undefined || value === null ? null : rule(value);

export type ValidationResult<T> = { ok: true; data: T } | { ok: false; errors: string[] };
export type ValidationOptions = {
  partial?: boolean; // pour une modification : les champs absents sont acceptés
  strict?: boolean; // un champ inconnu est une erreur (pas de « mass assignment »)
};

export function validate<T = Record<string, any>>(
  schema: Schema,
  input: unknown,
  options: ValidationOptions = {},
): ValidationResult<T> {
  const body = (input !== null && typeof input === "object" ? input : {}) as Record<string, unknown>;
  const errors: string[] = [];
  const data: Record<string, unknown> = {};
  for (const [field, rule] of Object.entries(schema)) {
    const value = body[field];
    if (value === undefined && options.partial) continue; // modification : champ non envoyé
    const error = rule(value);
    if (error) errors.push(`${field} : ${error}`);
    else if (value !== undefined) data[field] = typeof value === "string" ? value.trim() : value;
  }
  if (options.strict) {
    for (const key of Object.keys(body)) if (!(key in schema)) errors.push(`${key} : champ non autorisé`);
  }
  return errors.length > 0 ? { ok: false, errors } : { ok: true, data: data as T };
}

// Comme validate, mais lève une erreur 400 : le middleware d'erreurs fabrique la réponse
export function parse<T = Record<string, any>>(schema: Schema, input: unknown, options: ValidationOptions = {}): T {
  const result = validate<T>(schema, input, options);
  if (!result.ok) throw new AppError(400, "VALIDATION_ERROR", result.errors.join(" ; "));
  return result.data;
}
