import { AppError } from "../errors/app-error.js";

// "12" → 12 ; "abc", "0", "1.5" → erreur 400
export function parseId(raw: unknown): number {
  if (typeof raw !== "string" || !/^[1-9]\d*$/.test(raw)) {
    throw new AppError(400, "VALIDATION_ERROR", "Identifiant invalide");
  }
  return Number(raw);
}
