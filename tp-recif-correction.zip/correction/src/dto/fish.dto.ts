import { FISH_STATUSES, SPECIES, type Fish } from "../models/fish.js";
import { isoDate, oneOf, optional, text, type Schema } from "./validation.js";

// ------------------------------------------------------------------ ENTRÉE
// Ce que le client a le droit d'envoyer. Validé avec { strict: true } : un champ en trop → 400
// (impossible d'envoyer `status`, `id` ou `createdAt` : pas de « mass assignment »).
export const fishSchema: Schema = {
  name: text(1, 50),
  species: oneOf(SPECIES),
  breed: optional(text(0, 50)),
  birthDate: optional(isoDate),
  description: optional(text(0, 1000)),
  internalNotes: optional(text(0, 1000)),
};

// Les filtres de la query string : valeurs connues uniquement
export const fishFiltersSchema: Schema = {
  species: optional(oneOf(SPECIES)),
  status: optional(oneOf(FISH_STATUSES)),
};

// ------------------------------------------------------------------ SORTIE
// Ce qu'on montre, selon qui regarde. Chaque champ est choisi explicitement :
// un champ ajouté demain en base ne fuitera pas tout seul.
export type FishPublicDto = {
  id: number;
  name: string;
  species: Fish["species"];
  breed: string | null;
  birthDate: string | null;
  description: string;
  status: Fish["status"];
};

export type FishStaffDto = FishPublicDto & { internalNotes: string; createdAt: string };

export const toFishPublicDto = (a: Fish): FishPublicDto => ({
  id: a.id,
  name: a.name,
  species: a.species,
  breed: a.breed,
  birthDate: a.birthDate,
  description: a.description,
  status: a.status,
});

export const toFishStaffDto = (a: Fish): FishStaffDto => ({
  ...toFishPublicDto(a),
  internalNotes: a.internalNotes,
  createdAt: a.createdAt,
});
