import { REQUEST_STATUSES, type AdoptionRequest } from "../models/adoption-request.js";
import { email, oneOf, optional, text, type Schema } from "./validation.js";

// ------------------------------------------------------------------ ENTRÉE
export const adoptionSchema: Schema = {
  adopterName: text(1, 80),
  adopterEmail: email,
  message: optional(text(0, 500)),
};

export const adoptionFiltersSchema: Schema = { status: optional(oneOf(REQUEST_STATUSES)) };

// ------------------------------------------------------------------ SORTIE
// Au public : l'accusé de réception, sans données personnelles
export type AdoptionReceiptDto = Pick<AdoptionRequest, "id" | "fishId" | "status" | "createdAt">;
// Au personnel : la demande complète
export type AdoptionStaffDto = {
  id: number;
  fishId: number;
  adopterName: string;
  adopterEmail: string;
  message: string;
  status: AdoptionRequest["status"];
  createdAt: string;
  decidedAt: string | null;
};

export const toAdoptionReceiptDto = (r: AdoptionRequest): AdoptionReceiptDto => ({
  id: r.id,
  fishId: r.fishId,
  status: r.status,
  createdAt: r.createdAt,
});

export const toAdoptionStaffDto = (r: AdoptionRequest): AdoptionStaffDto => ({
  id: r.id,
  fishId: r.fishId,
  adopterName: r.adopterName,
  adopterEmail: r.adopterEmail,
  message: r.message,
  status: r.status,
  createdAt: r.createdAt,
  decidedAt: r.decidedAt,
});
