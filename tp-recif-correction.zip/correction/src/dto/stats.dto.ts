import type { RecifStats } from "../models/stats.js";

export type StatsDto = {
  fish: {
    total: number;
    byStatus: RecifStats["fishByStatus"];
    bySpecies: RecifStats["fishBySpecies"];
  };
  adoptionRequests: { pending: number; accepted: number; refused: number };
  averageDaysToAdoption: number | null;
};

export const toStatsDto = (s: RecifStats): StatsDto => ({
  fish: {
    total: Object.values(s.fishByStatus).reduce((sum, n) => sum + n, 0),
    byStatus: s.fishByStatus,
    bySpecies: s.fishBySpecies,
  },
  adoptionRequests: {
    pending: s.requestsByStatus.en_attente,
    accepted: s.requestsByStatus.acceptee,
    refused: s.requestsByStatus.refusee,
  },
  averageDaysToAdoption: s.averageDaysToAdoption,
});
