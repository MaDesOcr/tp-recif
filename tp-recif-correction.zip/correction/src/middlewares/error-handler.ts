import type { ErrorRequestHandler } from "express";
import { AppError } from "../errors/app-error.js";

// 4 paramètres : c'est ce qui fait de cette fonction un middleware d'erreurs.
// Enregistré en dernier, il transforme toute erreur en réponse JSON au même format.
export const errorHandler: ErrorRequestHandler = (err, req, res, _next) => {
  const requestId = req.id; // pour retrouver la ligne de journal correspondante
  if (err instanceof AppError) {
    res.status(err.status).json({ error: { code: err.code, message: err.message, requestId } });
    return;
  }
  if (err?.type === "entity.parse.failed") {
    res.status(400).json({ error: { code: "INVALID_JSON", message: "Le corps de la requête n'est pas un JSON valide", requestId } });
    return;
  }
  console.error(`[${requestId}]`, err);
  res.status(500).json({ error: { code: "INTERNAL", message: "Erreur interne", requestId } });
};
