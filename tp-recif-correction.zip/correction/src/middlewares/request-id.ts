import { randomUUID } from "node:crypto";
import type { RequestHandler } from "express";

// On ajoute `id` au type Request d'Express pour tout le projet
declare global {
  namespace Express {
    interface Request {
      id: string;
    }
  }
}

const VALID_ID = /^[\w-]{1,64}$/;

// Chaque requête reçoit un identifiant, renvoyé au client dans X-Request-Id.
// Si le client (un front, une autre API) en fournit un valide, on le garde :
// la même requête se suit alors d'un service à l'autre.
export const requestId: RequestHandler = (req, res, next) => {
  const incoming = req.get("X-Request-Id");
  req.id = incoming && VALID_ID.test(incoming) ? incoming : randomUUID();
  res.set("X-Request-Id", req.id);
  next();
};
