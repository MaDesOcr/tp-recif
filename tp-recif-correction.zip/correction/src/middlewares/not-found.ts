import type { RequestHandler } from "express";
import { AppError } from "../errors/app-error.js";

// Enregistré après toutes les routes : aucune n'a répondu
export const notFound: RequestHandler = (req, _res, next) => {
  next(new AppError(404, "NOT_FOUND", `Route ${req.method} ${req.originalUrl} inconnue`));
};
