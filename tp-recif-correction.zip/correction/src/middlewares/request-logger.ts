import type { RequestHandler } from "express";

// Une ligne par requête, écrite quand la réponse est partie (res.on("finish"))
export const requestLogger: RequestHandler = (req, res, next) => {
  const start = performance.now();
  res.on("finish", () => {
    const ms = (performance.now() - start).toFixed(1);
    console.log(`[${req.id}] ${req.method} ${req.originalUrl} → ${res.statusCode} (${ms} ms)`);
  });
  next();
};
