// Toute la configuration au même endroit, lue une seule fois au démarrage.
// Une variable obligatoire absente arrête l'application tout de suite (« fail fast »).
function required(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Variable d'environnement manquante : ${name} (voir .env.example)`);
  return value;
}

export const config = {
  port: Number(process.env.PORT ?? 3000),
  dbFile: process.env.DB_FILE ?? "recif.db",
  adminApiKey: required("ADMIN_API_KEY"),
  notifier: process.env.NOTIFIER ?? "console", // console | file
  outboxFile: process.env.OUTBOX_FILE ?? "outbox.jsonl",
};
