import Database from "better-sqlite3";
import { config } from "../config.js";

// Singleton « à la Node.js » : un module n'est évalué qu'une seule fois,
// donc tous les fichiers qui importent `db` partagent la même connexion.
export const db = new Database(config.dbFile);
db.pragma("foreign_keys = ON");
