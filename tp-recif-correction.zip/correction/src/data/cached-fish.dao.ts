import type { Fish, FishChanges, FishFilters, NewFish } from "../models/fish.js";
import type { FishDao } from "./fish.dao.js";

// Decorator : même interface que le DAO qu'il enveloppe, avec un cache en plus.
// Ni SqliteFishDao ni FishService ne sont modifiés.
export class CachedFishDao implements FishDao {
  private readonly cache = new Map<string, { fishes: Fish[]; expiresAt: number }>();

  constructor(
    private readonly inner: FishDao,
    private readonly ttlMs = 30_000,
    private readonly now: () => number = Date.now,
  ) {}

  async findAll(filters: FishFilters = {}): Promise<Fish[]> {
    const key = `${filters.species ?? "*"}|${filters.status ?? "*"}`;
    const hit = this.cache.get(key);
    if (hit && this.now() < hit.expiresAt) return hit.fishes;
    const fishes = await this.inner.findAll(filters);
    this.cache.set(key, { fishes, expiresAt: this.now() + this.ttlMs });
    return fishes;
  }

  // Lectures non mises en cache : on délègue
  findById(id: number): Promise<Fish | null> {
    return this.inner.findById(id);
  }

  // Écritures : on délègue, puis on vide le cache (le catalogue a changé)
  async create(data: NewFish): Promise<Fish> {
    const fish = await this.inner.create(data);
    this.cache.clear();
    return fish;
  }

  async update(id: number, changes: FishChanges): Promise<Fish | null> {
    const fish = await this.inner.update(id, changes);
    this.cache.clear();
    return fish;
  }

  async delete(id: number): Promise<boolean> {
    const deleted = await this.inner.delete(id);
    this.cache.clear();
    return deleted;
  }

  // Un changement de statut fait ailleurs (une adoption) doit aussi vider le cache
  invalidate(): void {
    this.cache.clear();
  }
}
