import type { Database } from "better-sqlite3";
import type { Fish, FishChanges, FishFilters, FishStatus, NewFish } from "../models/fish.js";

// Le contrat : ce que le reste de l'application peut demander sur les poissons
export interface FishDao {
  findAll(filters?: FishFilters): Promise<Fish[]>;
  findById(id: number): Promise<Fish | null>;
  create(data: NewFish): Promise<Fish>;
  update(id: number, changes: FishChanges): Promise<Fish | null>;
  delete(id: number): Promise<boolean>; // supprime aussi ses demandes d'adoption
}

type FishRow = {
  id: number;
  name: string;
  species: Fish["species"];
  breed: string | null;
  birth_date: string | null;
  description: string;
  internal_notes: string;
  status: FishStatus;
  created_at: string;
};

// Ligne SQL (snake_case) → objet du modèle (camelCase)
const toFish = (row: FishRow): Fish => ({
  id: row.id,
  name: row.name,
  species: row.species,
  breed: row.breed,
  birthDate: row.birth_date,
  description: row.description,
  internalNotes: row.internal_notes,
  status: row.status,
  createdAt: row.created_at,
});

// Liste blanche : seules ces propriétés peuvent devenir des colonnes
const COLUMNS: Record<keyof FishChanges, string> = {
  name: "name",
  species: "species",
  breed: "breed",
  birthDate: "birth_date",
  description: "description",
  internalNotes: "internal_notes",
};

export class SqliteFishDao implements FishDao {
  constructor(private readonly db: Database) {}

  async findAll(filters: FishFilters = {}): Promise<Fish[]> {
    // Les valeurs passent en paramètres nommés : plus d'injection SQL possible
    const rows = this.db
      .prepare(
        `SELECT * FROM fish
         WHERE (@species IS NULL OR species = @species)
           AND (@status IS NULL OR status = @status)
         ORDER BY id`,
      )
      .all({ species: filters.species ?? null, status: filters.status ?? null }) as FishRow[];
    return rows.map(toFish);
  }

  async findById(id: number): Promise<Fish | null> {
    const row = this.db.prepare("SELECT * FROM fish WHERE id = ?").get(id) as FishRow | undefined;
    return row ? toFish(row) : null;
  }

  async create(data: NewFish): Promise<Fish> {
    const info = this.db
      .prepare(
        `INSERT INTO fish (name, species, breed, birth_date, description, internal_notes, status, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'disponible', ?)`,
      )
      .run(data.name, data.species, data.breed ?? null, data.birthDate ?? null, data.description ?? "", data.internalNotes ?? "", new Date().toISOString());
    return (await this.findById(Number(info.lastInsertRowid)))!;
  }

  async update(id: number, changes: FishChanges): Promise<Fish | null> {
    const entries = (Object.keys(COLUMNS) as (keyof FishChanges)[]).filter((k) => changes[k] !== undefined);
    if (entries.length > 0) {
      const sets = entries.map((k) => `${COLUMNS[k]} = ?`).join(", ");
      this.db.prepare(`UPDATE fish SET ${sets} WHERE id = ?`).run(...entries.map((k) => changes[k]), id);
    }
    return this.findById(id);
  }

  async delete(id: number): Promise<boolean> {
    // Deux tables : tout ou rien
    const deleteAll = this.db.transaction((fishId: number) => {
      this.db.prepare("DELETE FROM adoption_requests WHERE fish_id = ?").run(fishId);
      return this.db.prepare("DELETE FROM fish WHERE id = ?").run(fishId).changes > 0;
    });
    return deleteAll(id);
  }
}
