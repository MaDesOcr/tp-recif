import type { AdoptionFilters, AdoptionRequest, NewAdoptionRequest } from "../models/adoption-request.js";
import type { AdoptionDao } from "./adoption.dao.js";

// Deuxième Decorator : les opérations d'adoption changent le statut d'un poisson,
// donc le catalogue en cache doit être vidé après chacune d'elles.
export class InvalidatingAdoptionDao implements AdoptionDao {
  constructor(
    private readonly inner: AdoptionDao,
    private readonly onFishChanged: () => void,
  ) {}

  findAll(filters?: AdoptionFilters): Promise<AdoptionRequest[]> {
    return this.inner.findAll(filters);
  }

  findById(id: number): Promise<AdoptionRequest | null> {
    return this.inner.findById(id);
  }

  findByFish(fishId: number): Promise<AdoptionRequest[]> {
    return this.inner.findByFish(fishId);
  }

  create(data: NewAdoptionRequest): Promise<AdoptionRequest> {
    return this.afterWrite(this.inner.create(data));
  }

  accept(id: number): Promise<AdoptionRequest> {
    return this.afterWrite(this.inner.accept(id));
  }

  refuse(id: number): Promise<AdoptionRequest> {
    return this.afterWrite(this.inner.refuse(id));
  }

  private async afterWrite(operation: Promise<AdoptionRequest>): Promise<AdoptionRequest> {
    const result = await operation;
    this.onFishChanged();
    return result;
  }
}
