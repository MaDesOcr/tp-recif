import type { Database } from "better-sqlite3";
import type { FishStatus } from "../models/fish.js";
import type { AdoptionFilters, AdoptionRequest, NewAdoptionRequest, RequestStatus } from "../models/adoption-request.js";

// Chaque opération qui touche une demande ET son fish est une transaction :
// le reste de l'application ne peut plus laisser la base dans un état incohérent.
export interface AdoptionDao {
  findAll(filters?: AdoptionFilters): Promise<AdoptionRequest[]>;
  findById(id: number): Promise<AdoptionRequest | null>;
  findByFish(fishId: number): Promise<AdoptionRequest[]>;
  create(data: NewAdoptionRequest): Promise<AdoptionRequest>; // le poisson passe « reserve »
  accept(id: number): Promise<AdoptionRequest>; // le poisson passe « adopte »
  refuse(id: number): Promise<AdoptionRequest>; // le poisson redevient « disponible »
}

type RequestRow = {
  id: number;
  fish_id: number;
  adopter_name: string;
  adopter_email: string;
  message: string;
  status: RequestStatus;
  created_at: string;
  decided_at: string | null;
};

const toRequest = (row: RequestRow): AdoptionRequest => ({
  id: row.id,
  fishId: row.fish_id,
  adopterName: row.adopter_name,
  adopterEmail: row.adopter_email,
  message: row.message,
  status: row.status,
  createdAt: row.created_at,
  decidedAt: row.decided_at,
});

export class SqliteAdoptionDao implements AdoptionDao {
  constructor(private readonly db: Database) {}

  async findAll(filters: AdoptionFilters = {}): Promise<AdoptionRequest[]> {
    const rows = this.db
      .prepare("SELECT * FROM adoption_requests WHERE (@status IS NULL OR status = @status) ORDER BY id")
      .all({ status: filters.status ?? null }) as RequestRow[];
    return rows.map(toRequest);
  }

  async findById(id: number): Promise<AdoptionRequest | null> {
    return this.selectById(id);
  }

  async findByFish(fishId: number): Promise<AdoptionRequest[]> {
    const rows = this.db.prepare("SELECT * FROM adoption_requests WHERE fish_id = ? ORDER BY id").all(fishId) as RequestRow[];
    return rows.map(toRequest);
  }

  async create(data: NewAdoptionRequest): Promise<AdoptionRequest> {
    const insert = this.db.transaction(() => {
      const info = this.db
        .prepare(
          `INSERT INTO adoption_requests (fish_id, adopter_name, adopter_email, message, status, created_at)
           VALUES (?, ?, ?, ?, 'en_attente', ?)`,
        )
        .run(data.fishId, data.adopterName, data.adopterEmail, data.message ?? "", new Date().toISOString());
      this.setFishStatus(data.fishId, "reserve");
      return Number(info.lastInsertRowid);
    });
    return this.selectById(insert())!;
  }

  async accept(id: number): Promise<AdoptionRequest> {
    return this.decide(id, "acceptee", "adopte");
  }

  async refuse(id: number): Promise<AdoptionRequest> {
    return this.decide(id, "refusee", "disponible");
  }

  private decide(id: number, decision: "acceptee" | "refusee", fishStatus: FishStatus): AdoptionRequest {
    const run = this.db.transaction(() => {
      this.db.prepare("UPDATE adoption_requests SET status = ?, decided_at = ? WHERE id = ?").run(decision, new Date().toISOString(), id);
      const request = this.selectById(id)!;
      this.setFishStatus(request.fishId, fishStatus);
      return request;
    });
    return run();
  }

  private setFishStatus(fishId: number, status: FishStatus) {
    this.db.prepare("UPDATE fish SET status = ? WHERE id = ?").run(status, fishId);
  }

  private selectById(id: number): AdoptionRequest | null {
    const row = this.db.prepare("SELECT * FROM adoption_requests WHERE id = ?").get(id) as RequestRow | undefined;
    return row ? toRequest(row) : null;
  }
}
