import type { Database } from "better-sqlite3";
import { FISH_STATUSES, SPECIES } from "../models/fish.js";
import { REQUEST_STATUSES } from "../models/adoption-request.js";
import type { RecifStats } from "../models/stats.js";

export interface StatsDao {
  getStats(): Promise<RecifStats>;
}

type CountRow = { key: string; n: number };

// Transforme [{ key: "betta", n: 2 }] en { koi: 0, betta: 2, … } : toutes les clés, même à zéro
function countsByKey<K extends string>(keys: readonly K[], rows: CountRow[]): Record<K, number> {
  const counts = Object.fromEntries(keys.map((k) => [k, 0])) as Record<K, number>;
  for (const row of rows) if (row.key in counts) counts[row.key as K] = row.n;
  return counts;
}

export class SqliteStatsDao implements StatsDao {
  constructor(private readonly db: Database) {}

  async getStats(): Promise<RecifStats> {
    const count = (sql: string) => this.db.prepare(sql).all() as CountRow[];
    const delay = this.db
      .prepare(
        `SELECT AVG(julianday(r.decided_at) - julianday(a.created_at)) AS days
         FROM adoption_requests r JOIN fish a ON a.id = r.fish_id
         WHERE r.status = 'acceptee'`,
      )
      .get() as { days: number | null };

    return {
      fishByStatus: countsByKey(FISH_STATUSES, count("SELECT status AS key, COUNT(*) AS n FROM fish GROUP BY status")),
      fishBySpecies: countsByKey(SPECIES, count("SELECT species AS key, COUNT(*) AS n FROM fish GROUP BY species")),
      requestsByStatus: countsByKey(REQUEST_STATUSES, count("SELECT status AS key, COUNT(*) AS n FROM adoption_requests GROUP BY status")),
      averageDaysToAdoption: delay.days,
    };
  }
}
