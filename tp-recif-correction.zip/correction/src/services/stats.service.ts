import type { StatsDao } from "../data/stats.dao.js";
import type { RecifStats } from "../models/stats.js";

export class StatsService {
  constructor(private readonly stats: StatsDao) {}

  async get(): Promise<RecifStats> {
    const stats = await this.stats.getStats();
    const days = stats.averageDaysToAdoption;
    // Règle d'affichage du Récif : un chiffre après la virgule
    return { ...stats, averageDaysToAdoption: days === null ? null : Math.round(days * 10) / 10 };
  }
}
