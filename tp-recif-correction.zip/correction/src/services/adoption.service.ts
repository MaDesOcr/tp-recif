import type { AdoptionDao } from "../data/adoption.dao.js";
import type { FishDao } from "../data/fish.dao.js";
import { AppError } from "../errors/app-error.js";
import type { AdoptionFilters, AdoptionRequest } from "../models/adoption-request.js";
import type { Fish } from "../models/fish.js";
import type { Notification, Notifier } from "../notifications/notifier.js";

export type AdoptionInput = { adopterName: string; adopterEmail: string; message?: string };

export class AdoptionService {
  constructor(
    private readonly adoptions: AdoptionDao,
    private readonly fishes: FishDao,
    private readonly notifier: Notifier, // console, fichier, email… le service ne sait pas lequel
  ) {}

  async request(fishId: number, input: AdoptionInput): Promise<AdoptionRequest> {
    const fish = await this.findFish(fishId);
    if (fish.status !== "disponible") throw new AppError(409, "CONFLICT", "Ce poisson n'est plus disponible");
    const request = await this.adoptions.create({ fishId, ...input });
    await this.notify({
      to: request.adopterEmail,
      subject: `Demande d'adoption reçue pour ${fish.name}`,
      body: `Bonjour ${request.adopterName}, nous avons bien reçu votre demande pour ${fish.name}. Le Récif vous répondra rapidement.`,
    });
    return request;
  }

  list(filters: AdoptionFilters = {}): Promise<AdoptionRequest[]> {
    return this.adoptions.findAll(filters);
  }

  async accept(id: number): Promise<AdoptionRequest> {
    await this.getPending(id);
    const request = await this.adoptions.accept(id);
    const fish = await this.findFish(request.fishId);
    await this.notify({
      to: request.adopterEmail,
      subject: `Demande acceptée : ${fish.name} vous attend !`,
      body: `Bonjour ${request.adopterName}, bonne nouvelle : votre demande d'adoption pour ${fish.name} est acceptée. Contactez le Récif pour organiser la remise du poisson.`,
    });
    return request;
  }

  async refuse(id: number): Promise<AdoptionRequest> {
    await this.getPending(id);
    const request = await this.adoptions.refuse(id);
    const fish = await this.findFish(request.fishId);
    await this.notify({
      to: request.adopterEmail,
      subject: `Votre demande pour ${fish.name}`,
      body: `Bonjour ${request.adopterName}, nous sommes désolés : votre demande d'adoption pour ${fish.name} a été refusée. D'autres poissons attendent un nouvel aquarium.`,
    });
    return request;
  }

  private async findFish(id: number): Promise<Fish> {
    const fish = await this.fishes.findById(id);
    if (!fish) throw new AppError(404, "NOT_FOUND", `Poisson ${id} introuvable`);
    return fish;
  }

  private async getPending(id: number): Promise<AdoptionRequest> {
    const request = await this.adoptions.findById(id);
    if (!request) throw new AppError(404, "NOT_FOUND", `Demande ${id} introuvable`);
    if (request.status !== "en_attente") throw new AppError(409, "CONFLICT", "Demande déjà traitée");
    return request;
  }

  // La demande est enregistrée : une panne d'envoi ne doit pas la faire échouer
  private async notify(notification: Notification): Promise<void> {
    try {
      await this.notifier.send(notification);
    } catch (err) {
      console.error("Notification non envoyée", err);
    }
  }
}
