import type { FishDao } from "../data/fish.dao.js";
import { AppError } from "../errors/app-error.js";
import type { Fish, FishChanges, FishFilters, NewFish } from "../models/fish.js";

// Les règles du Récif sur les poissons. Aucune trace d'HTTP ni de SQL ici :
// le service reçoit un FishDao, n'importe lequel (SQLite, mémoire, cache…).
export class FishService {
  constructor(private readonly fishes: FishDao) {}

  list(filters: FishFilters = {}): Promise<Fish[]> {
    return this.fishes.findAll(filters);
  }

  async get(id: number): Promise<Fish> {
    const fish = await this.fishes.findById(id);
    if (!fish) throw new AppError(404, "NOT_FOUND", `Poisson ${id} introuvable`);
    return fish;
  }

  create(data: NewFish): Promise<Fish> {
    return this.fishes.create(data);
  }

  async update(id: number, changes: FishChanges): Promise<Fish> {
    await this.get(id);
    return (await this.fishes.update(id, changes))!;
  }

  async remove(id: number): Promise<void> {
    await this.get(id);
    await this.fishes.delete(id);
  }
}
