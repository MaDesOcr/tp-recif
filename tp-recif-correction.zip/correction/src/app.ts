import express from "express";
import { AdoptionController } from "./controllers/adoption.controller.js";
import { FishController } from "./controllers/fish.controller.js";
import { StatsController } from "./controllers/stats.controller.js";
import { config } from "./config.js";
import { SqliteAdoptionDao } from "./data/adoption.dao.js";
import { SqliteFishDao } from "./data/fish.dao.js";
import { CachedFishDao } from "./data/cached-fish.dao.js";
import { db } from "./data/db.js";
import { InvalidatingAdoptionDao } from "./data/invalidating-adoption.dao.js";
import { SqliteStatsDao } from "./data/stats.dao.js";
import { errorHandler } from "./middlewares/error-handler.js";
import { notFound } from "./middlewares/not-found.js";
import { requestId } from "./middlewares/request-id.js";
import { requestLogger } from "./middlewares/request-logger.js";
import { createNotifier } from "./notifications/notifier.factory.js";
import { adoptionRoutes } from "./routes/adoption.routes.js";
import { fishRoutes } from "./routes/fish.routes.js";
import { statsRoutes } from "./routes/stats.routes.js";
import { AdoptionService } from "./services/adoption.service.js";
import { FishService } from "./services/fish.service.js";
import { StatsService } from "./services/stats.service.js";

// app.ts est la « racine de composition » : le seul endroit qui choisit
// les implémentations concrètes et les assemble.
export function createApp() {
  // Données : les Decorators s'empilent autour des DAO SQLite, sans les modifier
  const fishDao = new CachedFishDao(new SqliteFishDao(db), 30_000);
  const adoptionDao = new InvalidatingAdoptionDao(new SqliteAdoptionDao(db), () => fishDao.invalidate());
  const statsDao = new SqliteStatsDao(db);
  // Services techniques : le canal est choisi par la configuration (Factory)
  const notifier = createNotifier(config.notifier);
  // Métier
  const fishService = new FishService(fishDao);
  const adoptionService = new AdoptionService(adoptionDao, fishDao, notifier);
  const statsService = new StatsService(statsDao);
  // HTTP
  const fishController = new FishController(fishService);
  const adoptionController = new AdoptionController(adoptionService);
  const statsController = new StatsController(statsService);

  const app = express();
  app.use(requestId); // en premier : tout le monde en profite, même les erreurs
  app.use(requestLogger);
  app.use(express.json());
  app.use(fishRoutes(fishController));
  app.use(adoptionRoutes(adoptionController));
  app.use(statsRoutes(statsController));
  app.use(notFound);
  app.use(errorHandler);
  return app;
}
