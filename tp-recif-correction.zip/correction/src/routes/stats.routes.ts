import { Router } from "express";
import type { StatsController } from "../controllers/stats.controller.js";

export function statsRoutes(controller: StatsController): Router {
  const router = Router();
  router.get("/stats", controller.get);
  return router;
}
