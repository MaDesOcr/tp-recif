import type { RequestHandler } from "express";
import { fishFiltersSchema, fishSchema, toFishPublicDto, toFishStaffDto } from "../dto/fish.dto.js";
import { parse } from "../dto/validation.js";
import type { FishChanges, FishFilters, NewFish } from "../models/fish.js";
import { parseId } from "../dto/common.js";
import type { FishService } from "../services/fish.service.js";

// Le contrôleur traduit HTTP ↔ service : DTO d'entrée → service → DTO de sortie.
// Méthodes fléchées : `this` reste lié quand Express les appelle.
export class FishController {
  constructor(private readonly fishes: FishService) {}

  list: RequestHandler = async (req, res) => {
    const fishes = await this.fishes.list(parse<FishFilters>(fishFiltersSchema, req.query));
    res.json(fishes.map(toFishPublicDto));
  };

  getOne: RequestHandler = async (req, res) => {
    res.json(toFishPublicDto(await this.fishes.get(parseId(req.params.id))));
  };

  create: RequestHandler = async (req, res) => {
    const fish = await this.fishes.create(parse<NewFish>(fishSchema, req.body, { strict: true }));
    res.status(201).json(toFishStaffDto(fish));
  };

  update: RequestHandler = async (req, res) => {
    const id = parseId(req.params.id);
    res.json(toFishStaffDto(await this.fishes.update(id, parse<FishChanges>(fishSchema, req.body, { partial: true, strict: true }))));
  };

  remove: RequestHandler = async (req, res) => {
    await this.fishes.remove(parseId(req.params.id));
    res.status(204).end();
  };
}
