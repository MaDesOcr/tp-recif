import type { RequestHandler } from "express";
import { adoptionFiltersSchema, adoptionSchema, toAdoptionReceiptDto, toAdoptionStaffDto } from "../dto/adoption.dto.js";
import { parse } from "../dto/validation.js";
import type { AdoptionFilters } from "../models/adoption-request.js";
import { parseId } from "../dto/common.js";
import type { AdoptionInput, AdoptionService } from "../services/adoption.service.js";

export class AdoptionController {
  constructor(private readonly adoptions: AdoptionService) {}

  create: RequestHandler = async (req, res) => {
    const request = await this.adoptions.request(parseId(req.params.id), parse<AdoptionInput>(adoptionSchema, req.body, { strict: true }));
    res.status(201).json(toAdoptionReceiptDto(request));
  };

  list: RequestHandler = async (req, res) => {
    const requests = await this.adoptions.list(parse<AdoptionFilters>(adoptionFiltersSchema, req.query));
    res.json(requests.map(toAdoptionStaffDto));
  };

  accept: RequestHandler = async (req, res) => {
    res.json(toAdoptionStaffDto(await this.adoptions.accept(parseId(req.params.id))));
  };

  refuse: RequestHandler = async (req, res) => {
    res.json(toAdoptionStaffDto(await this.adoptions.refuse(parseId(req.params.id))));
  };
}
