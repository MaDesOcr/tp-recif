import type { RequestHandler } from "express";
import { toStatsDto } from "../dto/stats.dto.js";
import type { StatsService } from "../services/stats.service.js";

export class StatsController {
  constructor(private readonly stats: StatsService) {}

  get: RequestHandler = async (_req, res) => {
    res.json(toStatsDto(await this.stats.get()));
  };
}
