import type { FishStatus, Species } from "./fish.js";
import type { RequestStatus } from "./adoption-request.js";

export type RecifStats = {
  fishByStatus: Record<FishStatus, number>;
  fishBySpecies: Record<Species, number>;
  requestsByStatus: Record<RequestStatus, number>;
  averageDaysToAdoption: number | null; // de l'arrivée du poisson à l'acceptation
};
