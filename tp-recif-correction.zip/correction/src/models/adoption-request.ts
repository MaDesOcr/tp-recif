export const REQUEST_STATUSES = ["en_attente", "acceptee", "refusee"] as const;
export type RequestStatus = (typeof REQUEST_STATUSES)[number];

export type AdoptionRequest = {
  id: number;
  fishId: number;
  adopterName: string;
  adopterEmail: string;
  message: string;
  status: RequestStatus;
  createdAt: string;
  decidedAt: string | null;
};

export type NewAdoptionRequest = {
  fishId: number;
  adopterName: string;
  adopterEmail: string;
  message?: string;
};

export type AdoptionFilters = { status?: RequestStatus };
